import React from 'react'

const Manageschools = () => {
  return (
    <div>Manageschools</div>
  )
}

export default Manageschools