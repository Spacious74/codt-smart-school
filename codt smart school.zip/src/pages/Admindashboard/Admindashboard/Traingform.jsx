import React from 'react'

const Traingform = () => {
  return (
    <div>Traingform</div>
  )
}

export default Traingform