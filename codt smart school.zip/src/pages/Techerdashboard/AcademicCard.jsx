import React, { useState } from 'react';
import { Box, Typography, Avatar, Button, Grid, Paper, Card, CardContent, Tabs, Tab } from '@mui/material';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

import { Link } from "react-router-dom";
ChartJS.register(ArcElement, Tooltip, Legend);




import {
  School,
  Person,
  LiveTv,
  AttachMoney,
  Receipt,
  Report,
  Campaign,
  Laptop,
  Search,
  Public,
} from "@mui/icons-material";

const data = [
  {
    icon: <Person sx={{ fontSize: "48px", color: "blue" }} />,
    label: "Exams",
    route: "/teacher/academics/exam",
  },
  
  {
    icon: <LiveTv sx={{ fontSize: "48px", color: "orange" }} />,
    label: "Assignments",
    route: "/teacher/academics/assignment",
  },
  
  {
    icon: <Receipt sx={{ fontSize: "48px", color: "brown" }} />,
    label: "Syllabus",
    route: "/teacher/academics/syllabus",
  },
 
 
];






const Teacheracademics = () => {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const performanceData = {
    datasets: [
      {
        data: [25, 50, 100],
        backgroundColor: ['#f3f4f6', '#503dff', '#cbd5e1'],
        borderWidth: 0,
      },
    ],
  };

  const attendanceData = {
    datasets: [
      {
        data: [73, 27],
        backgroundColor: ['#41b8d5', '#6ce5e8'],
        cutout: '70%',
      },
    ],
  };
 

  return (
    <>
     <Grid container spacing={2} mt={4} ml={2} mb={5} display="flex">
                {data.map((item, idx) => (
                  <Grid item xs={4} sm={2.5} md={3} lg={1.5} key={idx} > 
                    <Link to={item.route}>
                      <Box
                        sx={{
                          border: "2px solid #503dff",
                          borderRadius: "8px",
                          padding: "16px",
                          textAlign: "center",
                          width: "100%",
                          height: "120px",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          backgroundColor: "#f9f9f9",
                        }}
                      >
                        {item.icon}
                      </Box>
                      <Typography variant="body1" align="center" sx={{ mt: 1 }}>
                        {item.label}
                      </Typography>
                    </Link>
                  </Grid>
                ))}
      

       </Grid>
             

    </>
  )
};

export default Teacheracademics;
